#include "StringBuffer.h"
#include <memory>
#include <iostream>
using namespace std;
StringBuffer::StringBuffer() {
    this->_strbuf = 0;
    this->_length = 0;
    this->_refcount = 1;
}
StringBuffer::~StringBuffer() {
    delete[] this->_strbuf;
}
StringBuffer::StringBuffer(const StringBuffer& newString) {
    this->_strbuf = new char[newString.length()];
    this->_length = newString.length();
    this->smartCopy(newString._strbuf, _length);
}
StringBuffer::StringBuffer(char* newString, int length) {
    _length = length;
    delete[] _strbuf;
    _strbuf = new char[length];
    _strbuf = newString;
}
void StringBuffer::smartCopy(StringBuffer* newString) {
    int shorterLength = 0;
    (this->_length < newString->_length) ? shorterLength = this->_length : shorterLength = newString->_length;
    int it = 0;
    while (it < shorterLength) {
        *_strbuf++ = *(newString->_strbuf)++;
        it++;
    }
}
void StringBuffer::smartCopy(char* newString, int length) {
    this->_length = length;
    int it = 0;
    while (it < length) {
        *_strbuf++ = *newString++;
        it++;
    }
}
void StringBuffer::revSmartCopy(char* newString) {
    int it = 0;
    while (it < _length) {
        newString[it] = _strbuf[it];
        it++;
    }
}
void StringBuffer::reserve(int n) {
    if (_length < n) {
        int newlength = n;
        char* newbuf = new char[newlength];
        this->revSmartCopy(newbuf);
        delete[] this->_strbuf;
         this->_strbuf = newbuf;
        this->_length = newlength;
    }
}
void StringBuffer::append(char c) {
    this->_strbuf[this->_length - 1] = c;
}

int StringBuffer::length() const {
    return this->_length;
}
char StringBuffer::charAt(int index) const {
    if (index < _length) {
        return _strbuf[index];
    } else {

    }
}
