#include <cstdlib>
#include <iostream>
#include<cstring>
#include "StringBuffer.h"
#include "String.h"
#include <stdio.h>
#include <stdlib.h>
#include "combined.h"

using namespace std;

void testFunc(){

        int tmp =0;
	int i=0;
  cout<<"\n\nCOW with hello count!"<<endl;

    //COW with hello count given
    char* hello = new char;
     hello[0]='h';
     hello[1]='e';
    String str2(hello,8);
    cout<<"str2 smart_string_length = "<<str2.length()<<std::endl;
    cout<<hello<<endl;
    String str(str2);
    cout<<hello<<endl;
    cout<<"str smart_string_length = "<<str.length()<<endl;
    cout<<"new str new_char_Index 0 = "<<str.charAt(0)<<endl;
    str2.append('l');
    cout<<"new str smart_string_length = "<<str.length()<<endl;
    cout<<"new str2 smart_string_length = "<<str2.length()<<endl;
    
//COW linking with daim
 cout<<"\n\nCOW linking with daim count!"<<endl;
tmp = 0;
       cow_link* smart_pointer_object4 = new cow_link();
	smart_pointer_object4->string_reservat(17);
	smart_pointer_object4->append_char('d');
	smart_pointer_object4->append_char('a');
	smart_pointer_object4->append_char('i');
	smart_pointer_object4->append_char('m');
      	cout<<"length of obj4 in cow linking = "<<smart_pointer_object4->smart_string_length()<<endl;

	cow_link* smart_pointer_object5 = new cow_link();
	smart_pointer_object5->string_reservat(17);
	*smart_pointer_object4 = *smart_pointer_object5;
if(tmp!=1)
cout<<"length of obj5 in cow linking = "<<smart_pointer_object5->smart_string_length()<<endl;

i=0;

while(i<4){

	{
		if(smart_pointer_object4->new_char_Index(i) != smart_pointer_object5->new_char_Index(i))
		{
	                cout<<"not successfully appended"<<endl;
			tmp = 1;
		}
	}

i++;
}		
if(tmp!=1)
cout <<"successfully appended cow linking test"<<endl;


//Copied Pointer with daim 
  tmp = 0; 
 	cout<<"\n\nSmart String Coppied pointers check!"<<endl;

        copy_smart_pointers smart_pointer_object2;
	smart_pointer_object2.string_reservat(17);
	smart_pointer_object2.append_char('d');
	smart_pointer_object2.append_char('a');
        smart_pointer_object2.append_char('i');
	 smart_pointer_object2.append_char('m');
         
        cout<<"obj 2 string length = "<<smart_pointer_object2.smart_string_length()<<std::endl;
	
       copy_smart_pointers smart_pointer_object3(smart_pointer_object2);
       cout<<"smart_pointer_object3 length = "<<smart_pointer_object3.smart_string_length()<<endl;
	i=0;


while(i<4){
	{
		if(smart_pointer_object2.new_char_Index(i) != smart_pointer_object3.new_char_Index(i))
		{
			cout<<"copied pointer append characters not successfull!"<<endl;
			tmp = 1;
		}
	}
   i++;
}
if(tmp!=1)
cout<<"copied pointer append characters successfull!"<<endl;



cout<<"Smart String owned Pointer!" <<endl;
	pointer_Ownership* smart_pointer_object = new pointer_Ownership();
	smart_pointer_object->string_reservat(17);
	smart_pointer_object->append_char('d');
        smart_pointer_object->append_char('a');
	smart_pointer_object->append_char('i');
	smart_pointer_object->append_char('m');

	cout<<" obj length = "<<smart_pointer_object->smart_string_length()<<std::endl;

	pointer_Ownership* smart_pointer_object1 = new pointer_Ownership(*smart_pointer_object);
	smart_pointer_object1->string_reservat(17);
	*smart_pointer_object1 = *smart_pointer_object;
         tmp =0;
	cout<<"pointer obj 1 = "<<smart_pointer_object1->smart_string_length()<<std::endl;
     
i=0; 
      while(i<4){
	
	
		if(smart_pointer_object->new_char_Index(i) != smart_pointer_object1->new_char_Index(i))
		{
			cout<<"owned pointer appended not successfull!"<<endl;
			tmp = 1;
		}
	
        i++;
}
	if(tmp!=1)
		cout <<"Owned Pointer appended Test Successful!!!"<<endl;

}


int main(int argc, char** argv) {
     
    testFunc();
    return 0;
}
