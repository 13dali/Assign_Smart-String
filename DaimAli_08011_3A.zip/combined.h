#include<cstring>
#include "StringBuffer.h"
#include "String.h"
#include <stdio.h>
#include <cstdlib>
#include <iostream>
#include <stdlib.h>

//copied pointer for smart string
class copy_smart_pointers{

private:
    char* char_Str_buff;                                   
    int smart_str_length;                                       

public :

copy_smart_pointers(const copy_smart_pointers& newVariable)
{
    char_Str_buff = new char [newVariable.smart_str_length];
    strcpy(char_Str_buff, newVariable.char_Str_buff);
    smart_str_length = newVariable.smart_str_length;       
}


copy_smart_pointers(char* smart_string,int smart_String_length)
{
    char_Str_buff = smart_string;
    smart_str_length = smart_String_length;
}
int smart_string_length() const{
	return smart_str_length;
}


char new_char_Index(int str_ind) const
{
	return char_Str_buff[str_ind];
}


void string_reservat(int str_ind)
{
	char_Str_buff = new char[str_ind];
}

void append_char(char character)
{
	char_Str_buff[smart_str_length] = character;
	smart_str_length += 1;
}

     copy_smart_pointers(char* ch = 0) throw()     : char_Str_buff(ch) 
     {
        smart_str_length = 0;
     }


copy_smart_pointers& operator= (const copy_smart_pointers &newVariable )
    { 
        if (this != &newVariable)
        {
            delete[] char_Str_buff;
            char_Str_buff = new char [newVariable.smart_str_length];
            strcpy(char_Str_buff, newVariable.char_Str_buff);
            smart_str_length = newVariable.smart_str_length;       
        }
        return *this;
    }

~copy_smart_pointers()  
{

    delete[] char_Str_buff;
   
}
};

//COW link hello:
class cow_link{

private:
                                     
    char*    string_buffer_new; 
    int len;
    
    cow_link*   previousPointer;
    cow_link*   nxt_poitner;
    
    void begin(const cow_link& newVariable) throw()
    { 
        string_buffer_new = newVariable.string_buffer_new;
        len = newVariable.len;
        nxt_poitner = newVariable.nxt_poitner;
        nxt_poitner->previousPointer = this;
      
        (const_cast<cow_link*>(&newVariable))->nxt_poitner = this;
    }

public :
    
int smart_string_length() const{
	return len;
}


char new_char_Index(int str_ind) const
{
	return string_buffer_new[str_ind];
}


void string_reservat(int str_ind)
{
	string_buffer_new = new char[str_ind];
}

    char* getPointer() const throw()   {return string_buffer_new;}
    

	cow_link(const cow_link& newVariable)
	{
        begin(newVariable);
        len = newVariable.len;
        
	}

void append_char(char character)
{
	if(notSame())
	{
		
		string_buffer_new[len] = character;
		len += 1;
	}
	else
	{
		char* tmp = new char[len];
		strncpy(tmp,string_buffer_new,len);
		rel();
		string_buffer_new = new char[len];
		strncpy(string_buffer_new,tmp,len);
		string_buffer_new[len] = character;
		len += 1;
		delete[] tmp;
		nxt_poitner = previousPointer = this;

	}
	
}
    

cow_link(cow_link* p = 0) throw()   : string_buffer_new(0) 
    {
        previousPointer = nxt_poitner = this;
    }


       cow_link& operator= (const cow_link &newVariable )
    { 

    	if (this != &newVariable) {
            rel();
            begin(newVariable);
        }
        return *this;
    }

    bool notSame()   const throw()  
     {
     	if(previousPointer == this && nxt_poitner == this)
     		return 1;
     	else
     		return 0;
     }

 void rel()
    {
        if (notSame()) 
        	delete[] string_buffer_new;
        else
        {
            previousPointer->nxt_poitner = nxt_poitner;
            nxt_poitner->previousPointer = previousPointer;
            previousPointer = nxt_poitner = 0;
           
        }
       
    }

  ~cow_link()  
{
       rel();

}

   };

//ownership of the pointers

class pointer_Ownership{

private:
	bool s_variable;
        char* string_buffer_new;                                   
        int smart_str_length; 

public :
    pointer_Ownership(char* strNew,int lenNew)
{
    string_buffer_new = strNew;
    smart_str_length = lenNew;
}

    pointer_Ownership(char* ch = 0) throw(): s_variable(ch!=0), string_buffer_new(ch) {}

void string_reservat(int str_ind)
{
	string_buffer_new = new char[str_ind];
}

   
    int smart_string_length() const{
	return smart_str_length;
}


char new_char_Index(int str_ind) const
{
	return string_buffer_new[str_ind];
}



void append_char(char char_new)
{
	string_buffer_new[smart_str_length] = char_new;
	smart_str_length += 1;
}
                   
    ~pointer_Ownership()  
{
	if (s_variable)
	{
		delete[] string_buffer_new;
	}
	delete string_buffer_new;
	
}

 


    pointer_Ownership& operator =(const pointer_Ownership &newVariable )
    { 

    	if (&newVariable != this) {
            if (string_buffer_new != newVariable.string_buffer_new)
            {
                if (s_variable)
                {
                	delete[] string_buffer_new;
                	delete string_buffer_new;
                }
                s_variable = newVariable.s_variable;
            }
            else if (newVariable.s_variable) s_variable = true;
            delete[] string_buffer_new;
            string_buffer_new = newVariable.remv_new_pntr();

            smart_str_length = newVariable.smart_str_length;
        }

        return *this;
    }

     
     pointer_Ownership(const pointer_Ownership& newVariable) throw(): s_variable(newVariable.s_variable), string_buffer_new(newVariable.remv_new_pntr()) 
	{
	}

 char* remv_new_pntr()  const throw()
    {
    	(const_cast<pointer_Ownership* >(this))->s_variable = false; 
    	return string_buffer_new;
    }

};


